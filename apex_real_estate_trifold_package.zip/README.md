# Internship Task Submission: Business Trifold Brochure

## Overview
This package provides a professional 6-panel **Trifold Brochure** designed for **Apex Real Estate Group**.

### Files Included
1. `apex_real_estate_trifold_brochure.pdf` - High-resolution print-ready 2-page landscape PDF.
2. `trifold_brochure_page1.png` - Outside spread (Flap, Back Cover, Front Cover).
3. `trifold_brochure_page2.png` - Inside spread (Services, Listings, Process).
4. `generate_brochure.py` - Python source code using ReportLab for vector rendering.
5. `README.md` - Technical notes and submission documentation.

---

## Design System
- **Dimensions**: 11" x 8.5" Landscape (3 equal 3.66" panels).
- **Colors**: Deep Navy (`#0F172A`), Gold (`#D97706`), Slate Gray (`#334155`), Off-White (`#F8FAFC`).
- **Structure**:
  - Panel 1 (Inside Flap): Stats & Why Choose Us
  - Panel 2 (Back Cover): Contact Info & QR Code
  - Panel 3 (Front Cover): Hero Banner & Brand Tagline
  - Panel 4-6 (Inside Spread): Services, Featured Listings, Process & Testimonial
